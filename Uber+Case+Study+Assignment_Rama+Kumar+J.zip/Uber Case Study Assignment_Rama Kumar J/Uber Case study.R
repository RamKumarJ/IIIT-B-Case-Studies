
#Reading the data from CSV file provided
setwd("C:\\Users\\RAM KUMAR\\Desktop\\IIIT B\\R\\Uber Case study")
Uber<-read.csv("Uber Request Data.csv",stringsAsFactors = FALSE)

#Cleansing the data
Uber$Request.timestamp <- gsub("/","-",Uber$Request.timestamp)
Uber$Drop.timestamp <- gsub("/","-",Uber$Drop.timestamp)
Uber$Request.timestamp = as.POSIXct(Uber$Request.timestamp, format = "%d-%m-%Y %H:%M")
Uber$Drop.timestamp = as.POSIXct(Uber$Drop.timestamp,format = "%d-%m-%Y %H:%M")
unclass(Uber$Request.timestamp)
unclass(Uber$Drop.timestamp)

str(Uber)
summary(Uber)
summary(Uber$Request.timestamp)
#Uber$Request.timestamp <- as.Date(Uber$Request.timestamp)
summary(Uber$Drop.timestamp)
Uber$Request_hr = format(Uber$Request.timestamp, "%H:%M")
#Uber$Request_hr <- as.numeric(Uber$Request_hr)

# dummy varibles
d  = format(Uber$Request.timestamp, "%H")
hr <- as.numeric(d)
Uber$Dropped_hr = format(Uber$Drop.timestamp, "%H:%M")

#Intrducing a derived varible into the data set
Uber$slots <- ifelse(hr<6, "Wee hours", ifelse(hr<11, "Rush Hours",ifelse(hr<16, "Noon Hours",ifelse(hr<19,"Peak Hours",ifelse(hr<24,"Night Hours" )))))
#Uber <- na.omit(Uber)
Uber
summary(Uber) # Data looks good

#Writing back the data into the table
write.table(Uber,"Uber_final.csv",row.names = FALSE,sep = ",")


###Visulaize the issue using the Plots
library(ggplot2)
ggplot(Uber, aes(slots)) + geom_histogram(stat = "count")
ggplot(Uber, aes(x = Pickup.point, col = factor(Status))) + geom_histogram(stat = "count")
ggplot(Uber, aes(x = Status, col = factor(Pickup.point))) + geom_histogram(stat = "count")
ggplot(Uber, aes(x = slots, col = factor(Status))) + geom_histogram(stat = "count")
ggplot(Uber, aes(x = slots, col = factor(Pickup.point))) + geom_histogram(stat = "count")



