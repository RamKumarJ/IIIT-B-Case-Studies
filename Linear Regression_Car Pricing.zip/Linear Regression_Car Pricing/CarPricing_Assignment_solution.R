
##############################################Data understanding, preparation and EDA#######################################

library(swirl)
ls()
rm(list=ls())
library(stringr)
library(car)
library(mass)

install_course()
CarPricing<- read.csv("CarPricing_Assignment.csv", stringsAsFactors = FALSE)
View(CarPricing)
str(CarPricing)

#2. Remove the duplicates
unique(CarPricing)

#3. Check the missing value
sum(is.na(CarPricing))

#4. Treat the outliers (if any)
quantile(CarPricing$symboling,seq(0,1,0.01))
# there is no sudden jump in the quantile values indicating there are no outliers in symboling.

quantile(CarPricing$wheelbase,seq(0,1,0.01))
CarPricing$wheelbase[which(CarPricing$wheelbase>115.544)]<-115.544

quantile(CarPricing$carlength,seq(0,1,0.01))
CarPricing$carlength[which(CarPricing$carlength>202.480)]<-202.480
CarPricing$carlength[which(CarPricing$carlength<155.900)]<-155.900

quantile(CarPricing$carwidth,seq(0,1,0.01))
# there is no sudden jump in the quantile values indicating there are no outliers in carwidth.

quantile(CarPricing$carheight,seq(0,1,0.01))
# there is no sudden jump in the quantile values indicating there are no outliers in carheight.


quantile(CarPricing$curbweight,seq(0,1,0.01))
CarPricing$curbweight[which(CarPricing$curbweight>3292.48)]<-3292.48
CarPricing$curbweight[which(CarPricing$curbweight<1874.000)]<-1874.000

quantile(CarPricing$enginesize,seq(0,1,0.01))
CarPricing$enginesize[which(CarPricing$enginesize>209.00)]<-209.00

quantile(CarPricing$boreratio,seq(0,1,0.01))
# there is no sudden jump in the quantile values indicating there are no outliers in boreratio.

quantile(CarPricing$stroke,seq(0,1,0.01))
# there is no sudden jump in the quantile values indicating there are no outliers in Stroke.

quantile(CarPricing$compressionratio,seq(0,1,0.01))
CarPricing$compressionratio[which(CarPricing$compressionratio>10.9400)]<-10.9400


quantile(CarPricing$horsepower,seq(0,1,0.01))
CarPricing$horsepower[which(CarPricing$horsepower>207.00)]<-207.00

quantile(CarPricing$peakrpm,seq(0,1,0.01))
CarPricing$peakrpm[which(CarPricing$peakrpm>6000)]<-6000

quantile(CarPricing$citympg,seq(0,1,0.01))
CarPricing$citympg[which(CarPricing$citympg>38.00)]<-38.00

quantile(CarPricing$highwaympg,seq(0,1,0.01))
CarPricing$highwaympg[which(CarPricing$highwaympg>46.92)]<-46.92

#Derived variables
#Separating the Carname variables to Company Name/CarModel name

str(CarPricing)
y <- as.data.frame(str_split_fixed(CarPricing$CarName, " ", 2))
colnames(y) <- c("CompName", "CarModel")
CarPricing<-cbind(CarPricing,y)
CarPricing$CarName<-NULL
View(CarPricing)
str(CarPricing)

#Removing the Car Model name as it should not be considered as an independent variable
CarPricing$CarModel<-NULL
View(CarPricing)

##Cleaning the Incorrect names of the Car Companies:
#This is to avoid creation of extra column when the categorical data is converted to numeric

levels(CarPricing$CompName)[levels(CarPricing$CompName)=="porcshce"] <- "porsche"
levels(CarPricing$CompName)[levels(CarPricing$CompName)=="Nissan"]   <- "nissan"
levels(CarPricing$CompName)[levels(CarPricing$CompName)=="toyouta"]  <- "toyota"
levels(CarPricing$CompName)[levels(CarPricing$CompName)=="vokswagen"]<- "volkswagen"
levels(CarPricing$CompName)[levels(CarPricing$CompName)=="maxda"]    <- "mazda"
levels(CarPricing$CompName)[levels(CarPricing$CompName)=="vw"]    <- "volkswagen"

View(CarPricing)

#Converting Factor Variable FuelType to Numeric:

summary(levels(CarPricing$fueltype))
levels(CarPricing$fueltype)<-c(1,0)
CarPricing$fueltype<-as.numeric(levels(CarPricing$fueltype))[CarPricing$fueltype]

#Converting Factor Variable Aspiration to Numeric:

levels(CarPricing$aspiration)<-c(1,0)
CarPricing$aspiration<-as.numeric(levels(CarPricing$aspiration))[CarPricing$aspiration]

#converting Factor variable DoorNumber to Numeric:

levels(CarPricing$doornumber)<-c(1,0)
CarPricing$doornumber<-as.numeric(levels(CarPricing$doornumber))[CarPricing$doornumber]

#converting Factor variable Engine allocation to Numeric:

levels(CarPricing$enginelocation)<-c(1,0)
CarPricing$enginelocation<-as.numeric(levels(CarPricing$enginelocation))[CarPricing$enginelocation]

#Converting Factor Variable CarBody to Numeric:
#Dummy variables
dummy_1 <- data.frame(model.matrix( ~carbody, data = CarPricing))
dummy_1<-dummy_1[,-1]

#Combine the Dummy variable to the Main Matrix:

CarPricing<-cbind(CarPricing[,-5],dummy_1)

#Converting Factor Variable EngineType to Numeric:

dummy_2<-data.frame(model.matrix(~enginetype,data = CarPricing))
dummy_2<-dummy_2[,-1]

#Combine the Dummy variable EngineBody to the Main Matrix:

CarPricing<-cbind(CarPricing[,-12],dummy_2)

#Converting Factor Variable EngineType to Numeric:

dummy_3<-data.frame(model.matrix(~drivewheel,data = CarPricing))
dummy_3<-dummy_3[,-1]

#Combine the Dummy variable EngineBody to the Main Matrix:

CarPricing<-cbind(CarPricing[,-5],dummy_3)

#Converting Factor Variable CylinderNumber to Numeric:

dummy_4<-data.frame(model.matrix(~cylindernumber,data = CarPricing))
dummy_4<-dummy_4[,-1]

#Combine the Dummy variable CylinderNumber to the Main Matrix:

CarPricing<-cbind(CarPricing[,-11],dummy_4)

#Converting Factor Variable FuelSystem to Numeric:

dummy_5<-data.frame(model.matrix(~fuelsystem,data = CarPricing))
dummy_5<-dummy_5[,-1]

#Combine the Dummy variable FuelSystem to the Main Matrix:

CarPricing<-cbind(CarPricing[,-12],dummy_5)
View(CarPricing)
levels(CarPricing$CompName)

#Converting Factor Variable CarName to Numeric:

dummy_6<-data.frame(model.matrix(~CompName,data = CarPricing))
dummy_6<-dummy_6[,-1]

#Combine the Dummy variable for CarName to the Main Matrix:

CarPricing<-cbind(CarPricing[,-20],dummy_6)

###########################################Model building and evaluation#################################################################

#Let's build the first model and store it in a variable model_1. Use model_1<-lm().
#Set the Seed and divide the data into training and test data set

set.seed(100)

train_ind<-sample(1:nrow(CarPricing),0.7*nrow(CarPricing))

train_data<-CarPricing[train_ind,]
View(train_data)

test_set <-CarPricing[-train_ind,]
View(test_set)

#Executing the First Multi Model:

model_1<-lm(price~.,data = train_data)
summary(model_1)

#The Summary of the above model has many insignificant variables

#Using the StepAIC function on the Training dataset to find

stepAIC(model_1,direction = "both")

model_2<-lm(formula = price ~ aspiration + enginelocation + carwidth + 
              curbweight + enginesize + boreratio + stroke + peakrpm + 
              citympg + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd + cylindernumberfive + cylindernumberthree + 
              fuelsystem2bbl + fuelsystemmpfi + CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_2)
vif(model_2)

#The Variables Enginesize,Car Width and Curbweight are highly collinear

c1<-data.frame(CarPricing$enginesize,CarPricing$carwidth,CarPricing$curbweight)
cor(c1)

#Removing Curbweight variable as it is has very high multicolinearity and as an independent variable it
#is heavily dependent Carwidth and Engine Size 

model_3<-lm(formula = price ~ aspiration + enginelocation 
            + boreratio + stroke + peakrpm + carwidth + enginesize +
              citympg + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd + cylindernumberfive + cylindernumberthree + 
              fuelsystem2bbl + fuelsystemmpfi + CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_3)
vif(model_3)

#Removing emfi as it has high VIF and p>0.05

model_4<-lm(formula = price ~ aspiration + enginelocation 
            + boreratio + stroke + peakrpm + carwidth + enginesize +
              +citympg + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd + cylindernumberfive + cylindernumberthree + 
              fuelsystem2bbl  + CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_4)
vif(model_4)

#Remove citympg

model_5<-lm(formula = price ~ aspiration + enginelocation 
            + boreratio + stroke + peakrpm + carwidth + enginesize +
              + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd + cylindernumberfive + cylindernumberthree + 
              fuelsystem2bbl  + CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_5)
vif(model_5)

#Remove FuelSystem 2bbl

model_6<-lm(formula = price ~ aspiration + enginelocation 
            + boreratio + stroke + peakrpm + carwidth + enginesize +
              + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd + cylindernumberfive + cylindernumberthree + 
              CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_6)
vif(model_6)

# Remove Bore ratio

model_7<-lm(formula = price ~ aspiration + enginelocation 
            + stroke + peakrpm + carwidth + enginesize +
              + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd + cylindernumberfive + cylindernumberthree + 
              CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_7)
vif(model_7)

#Remove Cylinder Number Five

model_8<-lm(formula = price ~ aspiration + enginelocation 
            + stroke + peakrpm + carwidth + enginesize +
              + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd  + cylindernumberthree + 
              CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNamesaab + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_8)
vif(model_8)


#Remove Companyname Saab

model_9<-lm(formula = price ~ aspiration + enginelocation 
            + stroke + peakrpm + carwidth + enginesize +
              + carbodyhardtop + carbodyhatchback + carbodysedan + 
              carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
              enginetyperotor + drivewheelrwd  + cylindernumberthree + 
              CompNamebmw + CompNamebuick + 
              CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
              CompNamemercury + CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
              CompNamerenault + CompNametoyota + CompNamevolkswagen, 
            data = train_data)
summary(model_9)
vif(model_9)


#Remove CompanyName Mercury

model_10<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + carwidth + enginesize +
               + carbodyhardtop + carbodyhatchback + carbodysedan + 
               carbodywagon + enginetypedohcv + enginetypel + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + cylindernumberthree + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_10)
vif(model_10)

#Removing Enginetypel

model_11<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + carwidth + enginesize +
               + carbodyhardtop + carbodyhatchback + carbodysedan + 
               carbodywagon + enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + cylindernumberthree + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_11)
vif(model_11)


#Remove Cylinder Numer Three

model_12<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + carwidth + enginesize +
               + carbodyhardtop + carbodyhatchback + carbodysedan + 
               carbodywagon + enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_12)
vif(model_12)

#Remove CarBody Sedan

model_13<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + carwidth + enginesize +
               + carbodyhardtop + carbodyhatchback  + 
               carbodywagon + enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_13)
vif(model_13)

#Remove Car Hatchback

model_14<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + carwidth + enginesize +
               + carbodyhardtop + carbodywagon  + 
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_14)
vif(model_14)

#Remove Carbodyhard top

model_15<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + carwidth + enginesize +
               +   carbodywagon +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_15)
vif(model_15)

#Remove Carbody Wagon

model_16<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + carbodywagon +
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_16)
vif(model_16)

model_17<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota + CompNamevolkswagen, 
             data = train_data)
summary(model_17)
vif(model_17)

#Remove Company Name Volkswagen

model_18<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNamerenault + CompNametoyota , 
             data = train_data)
summary(model_18)
vif(model_18)

#Remove Company Name Renault

model_19<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge + CompNamehonda + CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNametoyota , 
             data = train_data)
summary(model_19)
vif(model_19)

#Remove Company Name Honda

model_20<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge +  CompNamejaguar + CompNamemazda + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNametoyota , 
             data = train_data)
summary(model_20)
vif(model_20)

#Remove Company Name Mazda

model_21<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor + drivewheelrwd  + 
               CompNamebmw + CompNamebuick + 
               CompNamedodge +  CompNamejaguar + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNametoyota , 
             data = train_data)
summary(model_21)
vif(model_21)

#Remove Driver Wheel rwd

model_22<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamedodge +  CompNamejaguar + 
               CompNamemitsubishi + CompNamenissan + CompNameplymouth + 
               CompNametoyota , 
             data = train_data)
summary(model_22)
vif(model_22)

#Remove Company Name Nissan

model_23<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamedodge +  CompNamejaguar + 
               CompNamemitsubishi +  CompNameplymouth + 
               CompNametoyota , 
             data = train_data)
summary(model_23)
vif(model_23)

#Remove Toyota

model_24<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamedodge +  CompNamejaguar + 
               CompNamemitsubishi +  CompNameplymouth
             , 
             data = train_data)
summary(model_24)
vif(model_24)

#Remove dodge

model_25<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamejaguar + 
               CompNamemitsubishi +  CompNameplymouth
             , 
             data = train_data)
summary(model_25)
vif(model_25)

#Remove Plymouth

model_26<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypedohcv + enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamejaguar + 
               CompNamemitsubishi 
             , 
             data = train_data)
summary(model_26)
vif(model_26)

#Remove Engine pedo hcv

model_27<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamejaguar + 
               CompNamemitsubishi 
             , 
             data = train_data)
summary(model_27)
vif(model_27)

#Remove mitsubushi

model_28<-lm(formula = price ~ aspiration + enginelocation 
             + stroke + peakrpm + enginesize +
               enginetypeohcf + 
               enginetyperotor +  
               CompNamebmw + CompNamebuick + 
               CompNamejaguar 
             
             , 
             data = train_data)
summary(model_28)
vif(model_28)

View(test_set)

Predict_price<-predict(model_28,test_set[,-19])
test_set$test_price<-Predict_price


test_set$car_id<-seq(1,nrow(test_set))


View(test_set)



#correlation

cor_out<-cor(test_set$price,test_set$test_price)
View(cor_out)

r_squ<-cor_out^2
View(r_squ)














