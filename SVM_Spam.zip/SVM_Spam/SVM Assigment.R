############################ Email Classification Problem ############################
# 1. Business Understanding
# 2. Data Understanding
# 3. Data Preparation
# 4. Model Building 
#  4.1 Linear kernel
#  4.2 RBF Kernel
# 5 Hyperparameter tuning and cross validation

#####################################################################################

# 1. Business Understanding: 

# The "handwritten digit recognition" concept is diverse:
# 1. We have an image of a digit submitted by a user via a scanner, a tablet, or other digital devices
# 2. The goal is to develop a model that can correctly identify the digit (between 0-9) written in an image. 

#####################################################################################

# 2. Data Understanding: 

# Number of Instances: 59999
# Number of Attributes: 785 (784 continuous, 1 nominal class label)

#3. Data Preparation: 

##Loading Neccessary libraries

install.packages('caret', dependencies=TRUE)
install.packages('kernlab')
install.packages('dplyr')
install.packages('readr')
install.packages('ggplot2')
install.packages('gridExtra')
install.packages('e1071', dependencies=TRUE)

library('caret')
library('kernlab')
library('dplyr')
library('readr')
library('ggplot2')
library('gridExtra')
library('e1071')

#Loading Data
Writing_recogn <- read.csv("mnist_train.csv",stringsAsFactors = F)
Writing_test <- read.csv("mnist_test.csv",stringsAsFactors = F)

#Understanding Dimensions
dim(Writing_recogn)
dim(Writing_test)

#Structure of the dataset
str(Writing_recogn)
str(Writing_test)

#printing first few rows
head(Writing_recogn)
head(Writing_test)

#Exploring the data
summary(Writing_recogn)
summary(Writing_test)

# Checking missing value
sapply(Writing_recogn, function(x) sum(is.na(x))) # No missing values
sapply(Writing_test, function(x) sum(is.na(x))) # No missing values

#Making our target class to factor

Writing_recogn$X5<-factor(Writing_recogn$X5)
Writing_test$X7<-factor(Writing_test$X7)


# Splitting the data between train and test

set.seed(100)
indices = sample(1:nrow(Writing_recogn), 0.10*nrow(Writing_recogn))
train = Writing_recogn[indices,]
indices_Test = sample(1:nrow(Writing_test), 0.90*nrow(Writing_test))
test = Writing_test[indices_Test,]

# 4. Model Building

#Using Linear Kernel
Model_linear <- ksvm(X5~ ., data = train, scale = FALSE, kernel = "vanilladot")


# Predicting the model results 
Eval_linear<- predict(Model_linear, test)

# Confusion Matrix - Finding accuracy, Sensitivity and specificity
confusionMatrix(Eval_linear,test$X7)

#Using RBF Kernel
Model_RBF <- ksvm(X5~ ., data = train, scale = FALSE, kernel = "rbfdot")
Eval_RBF<- predict(Model_RBF, test)

#confusion matrix - RBF Kernel
confusionMatrix(Eval_RBF,test$X7)

############   Hyperparameter tuning and Cross Validation #####################

# We will use the train function from caret package to perform Cross Validation. 

#traincontrol function Controls the computational nuances of the train function.
# i.e. method =  CV means  Cross Validation.
#      Number = 2 implies Number of folds in CV.

trainControl <- trainControl(method="cv", number=5)


# Metric <- "Accuracy" implies our Evaluation metric is Accuracy.

metric <- "Accuracy"

#Expand.grid functions takes set of hyperparameters, that we shall pass to our model.

set.seed(7)
grid <- expand.grid(.sigma=c(0.025, 0.05), .C=c(0.1,0.5,1,2) )


#train function takes Target ~ Prediction, Data, Method = Algorithm
#Metric = Type of metric, tuneGrid = Grid of Parameters,
# trcontrol = Our traincontrol method.

fit.svm <- train(X5~., data=train, method="svmRadial", metric=metric, 
                 tuneGrid=grid, trControl=trainControl)

print(fit.svm)

plot(fit.svm)

#####################################################################
# Checking overfitting - Non-Linear - SVM
######################################################################

# Validating the model results on test data
evaluate_non_linear<- predict(fit.svm, test)
confusionMatrix(evaluate_non_linear, test$X7)




