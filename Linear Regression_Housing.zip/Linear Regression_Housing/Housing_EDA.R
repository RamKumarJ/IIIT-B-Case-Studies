library(swirl)
ls()
rm(list=ls())


install_course()
housing <- read.csv("housing.csv", stringsAsFactors = FALSE)
View(housing)
str(housing)
#1. Converting to factor
housing$radial_highways<-as.factor(housing$radial_highways)
str(housing)

#2. Remove the duplicates
unique(housing)

#3. Check the missing value
sum(is.na(housing))

#4. Treat the outliers (if any)
quantile(housing$crime_rate,seq(0,1,0.01))
housing$crime_rate[which(housing$crime_rate>25.0216600)]<-25.0216600

quantile(housing$residential_land,seq(0,1,0.01))
housing$residential_land[which(housing$residential_land>45.0)]<-45.0

quantile(housing$nitric_oxides,seq(0,1,0.01))
# there is no sudden jump in the quantile values indicating there are no outliers in nitric_oxides.

quantile(housing$weighted_distances,seq(0,1,0.01))
housing$weighted_distances[which(housing$weighted_distances>9.222770)]<-9.222770

quantile(housing$corporate_proportion,seq(0,1,0.01))
housing$corporate_proportion[which(housing$corporate_proportion<229.6060)]<-229.6060

#Dummy Variables
#housing$radial_highways <- ifelse(housing$radial_highways<4, "Near", ifelse(housing$radial_highways<7, "far",ifelse(housing$radial_highways<10, "very far")))
levels(housing$radial_highways)[1:3] <- "near"
str(housing)
levels(housing$radial_highways)[2:4] <- "far"
levels(housing$radial_highways)[3:5] <- "farthest"
str(housing)

View(housing)

#dummy varibles
dummy<-model.matrix(~radial_highways -1, data=housing)
dummy<-dummy[,-1]

housing_1<-cbind(housing[,-6], dummy)
View(housing_1)

