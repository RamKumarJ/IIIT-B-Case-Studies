#Loading Data into R#
loan_dataset <- read.csv("loan.csv", stringsAsFactors = FALSE)
str(loan_dataset)
library(stringr)
library(ggplot2)
library(dplyr)
install.packages("gridExtra")
library(gridExtra)
library(zoo)
install.packages("DescTools")
library(DescTools)
install.packages("ggthemes")
library(ggthemes)
install.packages("lubridate")
library(lubridate)

## ------------------ Cleaning LOAN df -----------------##
# Fixing Columns: Identify unnecessary columns #
lapply(loan_dataset, function(x) length(unique(x))) #gives count of unique values for all columns

#Removing unnecessary columns with only single value
new_loan_dataset <- loan_dataset[, -c(18,36,51:78,80:105,108:111)] 


# Look for duplicate values #
sum(duplicated(new_loan_dataset$member_id)) # No duplicate IDs here!!
sum(duplicated(new_loan_dataset$id)) # No duplicate IDs here!

#Check for NA values: No NA values for the main variables! #
sum(is.na(new_loan_dataset$member_id))
sum(is.na(new_loan_dataset$id))
sum(is.na(new_loan_dataset$loan_amnt))
sum(is.na(new_loan_dataset$funded_amnt))
sum(is.na(new_loan_dataset$funded_amnt_inv))
sum(is.na(new_loan_dataset$annual_inc))
sum(is.na(new_loan_dataset$delinq_2yrs))
sum(is.na(new_loan_dataset$dti))
sum(is.na(new_loan_dataset$purpose))
sum(is.na(new_loan_dataset$zip_code))
sum(is.na(new_loan_dataset$addr_state))
 

# Standardise Values #
new_loan_dataset$int_rate = as.numeric(gsub("\\%", "", new_loan_dataset$int_rate))
new_loan_dataset$desc[new_loan_dataset$desc==""] <- "NA" #Replace blank spaces with NA
new_loan_dataset$emp_title[new_loan_dataset$emp_title==""] <- "NA" #Replace blank spaces with NA
new_loan_dataset$emp_length[new_loan_dataset$emp_length=="n/a"] <- "NA" #Replace blank spaces with NA

new_loan_dataset$issue_d <- paste("01-",new_loan_dataset$issue_d, sep = "")
new_loan_dataset$issue_d <-as.Date(new_loan_dataset$issue_d, format="%d-%b-%y")

#Extract the year from the issue date
new_loan_dataset$issue_yr <- format(new_loan_dataset$issue_d, "%Y")

new_loan_dataset$earliest_cr_line <- paste("01-",new_loan_dataset$earliest_cr_line, sep = "")
new_loan_dataset$earliest_cr_line <-as.Date(new_loan_dataset$earliest_cr_line, format="%d-%b-%y")

#Extract the year from the earliest_cr_line
new_loan_dataset$cr_line_yr <- format(new_loan_dataset$earliest_cr_line, "%Y")

# Find outliers #
boxplot(new_loan_dataset$int_rate) #looks ok

library(outliers)
boxplot(new_loan_dataset$loan_amnt) #Since there are many values above the whiskers, we are considering them as genuine values instead of outliers.

boxplot(new_loan_dataset$annual_inc)
# Annual income of "6e+06" is a clear outlier, since there is no description and it is way out of the 
# the average annual income. I took median and replaced it with the same. 
median(new_loan_dataset$annual_inc)
new_loan_dataset$annual_inc[new_loan_dataset$annual_inc %in% "6e+06"] <- 59000
boxplot(new_loan_dataset$annual_inc)

max(new_loan_dataset$annual_inc) #The next maximum annual income is "3900000" and it looks genuine since
# the reason is clearly mentioned in the desc and loan stands paid off.

#Converting columns as factors

new_loan_dataset$term <- as.factor(new_loan_dataset$term)
str(new_loan_dataset$term)
new_loan_dataset$grade <- as.factor(new_loan_dataset$grade)
new_loan_dataset$sub_grade <- as.factor(new_loan_dataset$sub_grade)
new_loan_dataset$emp_length <- as.factor(new_loan_dataset$emp_length)
str(new_loan_dataset$emp_length)
new_loan_dataset$home_ownership <- as.factor(new_loan_dataset$home_ownership)
new_loan_dataset$verification_status <- as.factor(new_loan_dataset$verification_status)
new_loan_dataset$loan_status <- as.factor(new_loan_dataset$loan_status)
new_loan_dataset$purpose <- as.factor(new_loan_dataset$purpose)
new_loan_dataset$addr_state <- as.factor(new_loan_dataset$addr_state)

########Data Analysis to Follow################


new_loan_dataset$emp_length = factor(new_loan_dataset$emp_length)
new_loan_dataset$int_rate = factor(new_loan_dataset$int_rate)
new_loan_dataset$verification_status = factor(new_loan_dataset$verification_status)
new_loan_dataset$income_class <- cut(new_loan_dataset$annual_inc,4,c("Lower class","Middle Class","Upper Middle Class","Upper Class"))
new_loan_dataset$ROI_Class<- cut(new_loan_dataset$int_rate,3,c("lower","Nominal","Higher"))



table(new_loan_dataset$loan_status)
table(new_loan_dataset$home_ownership)
table(new_loan_dataset$emp_length)
table(new_loan_dataset$purpose)
table(new_loan_dataset$verification_status)
table(new_loan_dataset$income_class)
#summary(new_loan_dataset$income_class)
table(new_loan_dataset$int_rate)
summary(new_loan_dataset$int_rate)
summary(new_loan_dataset$issue_yr)

##############Visulization#######################

ggplot(data = new_loan_dataset,aes(x = grade))+geom_bar()
ggplot(data = new_loan_dataset, aes(term,loan_amnt))+geom_boxplot(aes(fill = grade))
ggplot(data = new_loan_dataset, aes(term,loan_amnt))+geom_boxplot(aes(fill = term))
ggplot(data = new_loan_dataset, aes(emp_length,loan_amnt))+geom_boxplot(aes(fill = term))
ggplot(data = new_loan_dataset, aes(emp_length,int_rate))+geom_boxplot(aes(fill = term))

ggplot(new_loan_dataset, aes(grade,int_rate))+ geom_boxplot(aes(fill = grade)) +
  labs(title = "Interest rate by grade",x = "Grade",y = "Interest rate")



Desc(new_loan_dataset$grade, main = "Grade distribution", plotit = 1)
Desc(new_loan_dataset$loan_amnt, main = "Loan Amount distribution", plotit = 1)

ggplot(data = new_loan_dataset,aes(x = loan_status))+geom_bar(aes(fill = term))
ggplot(data = new_loan_dataset,aes(x = verification_status))+geom_bar(aes(fill = term))
ggplot(data = new_loan_dataset,aes(x = purpose))+geom_bar(aes(fill = term))+coord_flip()
ggplot(data = new_loan_dataset,aes(x = loan_amnt))+geom_bar(aes(fill = term))+coord_flip()

ggplot(data = new_loan_dataset,aes(x=int_rate)) + geom_line(stat="density")+ xlim(0,20) + theme_solarized()
ggplot(data = new_loan_dataset,aes(x=int_rate , fill=term))  + geom_line(stat="density") + xlim(0,20)  + theme_solarized()

loanDataSummary <- new_loan_dataset %>% group_by(issue_yr) %>% dplyr::summarise(sloan_amnt = sum(loan_amnt),stotal_rec_int=sum(total_rec_int),stotal_rec_prncp = sum(total_rec_prncp))
amt_group_table = new_loan_dataset %>% select(issue_d, loan_status, loan_amnt) %>% group_by(issue_d,loan_status) %>% summarise(Amount = sum(loan_amnt))
ggplot(new_loan_dataset, aes(x = issue_yr, y = loan_amnt)) + geom_area(aes(fill = loan_status)) + labs(title = "Loan by issued year",x = "Issued Year",y = "Amount")

graphLoanAmount<- ggplot(loanDataSummary,aes(x=issue_yr,y=sloan_amnt,color = stotal_rec_int)) + geom_line()+ geom_point() + theme_solarized( ) + labs(y="Loan Amount",x="Year",color="Received Interest Rate")
graphPrincipalAmount<- ggplot(loanDataSummary,aes(x=issue_yr,y=stotal_rec_prncp) )+ geom_line(color="red")+ geom_point(color="blue") + theme_solarized( ) + labs(y="Principal Amount",x="Year")
graphInterestAmount<- ggplot(loanDataSummary,aes(x=issue_yr,y=stotal_rec_int) )+ geom_line()+ geom_point() + theme_solarized( ) + labs(y="Interest Amount",x="Year")
grid.arrange(graphLoanAmount,graphPrincipalAmount,graphInterestAmount)

ggplot(new_loan_dataset,aes(x=int_rate)) + geom_line(stat="density") + geom_histogram(fill="blue", colour="black",bins = 30) + expand_limits(y=0) + facet_grid( grade ~ term ) + theme_solarized()


       
